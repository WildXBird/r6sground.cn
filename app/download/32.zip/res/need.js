let CoreResVersion = 31;
require('nw.gui').Window.get().evalNWBin(null, './app/res/core.bin');