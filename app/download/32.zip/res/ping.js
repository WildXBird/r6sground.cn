function ping(ip, div = 0,last = 999999, method = 0) {
	last = last.replace("ms","");
	var ping = new XMLHttpRequest();
	if (ip.indexOf("dynamodb") != -1) {
		ping.open("GET", "http://" + ip + '/ping' , true);
	} else {
		if (0 == method) {
			ping.open("GET", "http://" + ip + "?t=" + new Date().getTime(), true);
		} else {
			ping.open(method, "http://" + ip + "?t=" + new Date().getTime(), true);
		}
	}
	ping.timeout = 3000;
	var start = new Date().getTime();
	ping.send();
	ping.onreadystatechange = function () {
		var end = new Date().getTime();
		if (ping.readyState == 4) {
			if (ping.status >= 200) {
				time = (end - start)-0;
				if(time < 2){
					time = 1;
				}
				if(time > last){	
					time = last;
				}
				var back = {};
				back['time'] = time;
				back['div'] = 'ping-ping-' + div;
				jback = JSON.stringify(back);
				postMessage(jback);
			}else{
				if(last>0){
					var back = {};
					back['time'] = last;
					back['div'] = 'ping-ping-' + div;
					jback = JSON.stringify(back);
					postMessage(jback);
				}else{
					var back = {};
					back['time'] = 9999;
					back['div'] = 'ping-ping-' + div;
					jback = JSON.stringify(back);
					postMessage(jback);
				}

			}
		}
	}
}
onmessage = function (e) {
	var input = eval('(' + e.data + ')');
	latertime = input.div*150;
	setTimeout("ping('" + input.ip + "','" + input.div + "','" + input.last + "');",latertime);
}