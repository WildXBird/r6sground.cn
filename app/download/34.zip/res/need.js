let CoreResVersion = 33;
require('nw.gui').Window.get().evalNWBin(null, './app/res/core.bin');