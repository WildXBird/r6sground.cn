let CoreResVersion = 35;
require('nw.gui').Window.get().evalNWBin(null, './app/res/core.bin');