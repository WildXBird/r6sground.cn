let CoreResVersion = 41;
require('nw.gui').Window.get().evalNWBin(null, './app/res/core.bin');